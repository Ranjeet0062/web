const mongoose=require("mongoose");
const fileSchema=mongoosse.Schema({
    file:{
        type:String
    },
    tag:{
        type:String
    }
})